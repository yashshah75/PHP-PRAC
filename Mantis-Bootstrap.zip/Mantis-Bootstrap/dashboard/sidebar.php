

 <!-- [ Sidebar Menu ] start -->
 <nav class="pc-sidebar">
  <div class="navbar-wrapper">
    <div class="m-header">
      <a href="" class="b-brand text-primary">
        <!-- ========   Change your logo from here   ============ --><br><br>
        <img src="images/1.jpg"  alt="logo"  style="width: 120px; height: 100px; margin-top:10px; margin-left:40px; display: block !important;">
        </a>
    </div>
    <div class="navbar-content">
    <br>
    <br>
      <ul class="pc-navbar">
        <li class="pc-item">
          <a href="index.php" class="pc-link">
            <span class="pc-micon"><i class="ti ti-dashboard"></i></span>
            <span class="pc-mtext">Dashboard</span>
          </a>
        <br>
          <a href="allpost.php" class="pc-link">
            <span class="pc-micon"><i class="ti ti-dashboard"></i></span>
            <span class="pc-mtext">All Post</span>
          </a>
        </li>
      </ul>
      
    </div>
  </div>
</nav>