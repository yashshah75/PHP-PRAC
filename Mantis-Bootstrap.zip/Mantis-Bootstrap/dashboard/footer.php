<footer class="pc-footer">
    <div class="footer-wrapper container-fluid">
      <div class="row">
        <div class="col-sm my-1">
          <p class="m-0">  crafted by Yash Shah &#9829; Distributed by <a href="https://themewagon.com/">ThemeWagon</a></p>
        </div>
      </div>
    </div>
  </footer>